#!/bin/bash
filelist='ls'
for filename in 
